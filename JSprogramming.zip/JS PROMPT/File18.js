const prompt=require("prompt-sync")();//import prompt function for input
//Q18.WAP to print entered name three times on the screen on separate line 
//using a single printing statements
let name=prompt("Enter name:");
console.log("\n",name,"\n",name,"\n",name);
