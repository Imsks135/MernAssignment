const prompt=require("prompt-sync")();//import prompt function for input
//Q17.WAP to print area of circle
let r=parseInt(prompt("Enter radius:"));
let area=3.14*r*r;
console.log("Area of circle:",area);