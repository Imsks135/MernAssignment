const prompt=require("prompt-sync")();//import prompt function for input
//Q1.WAP to print the pattern
// //INDIA
//        INDIA
//             INDIA
//                  INDIA
console.log("INDIA");
console.log("     INDIA");
console.log("          INDIA");
console.log("               INDIA");























