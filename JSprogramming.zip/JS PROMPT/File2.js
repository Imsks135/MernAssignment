const prompt=require("prompt-sync")();//import prompt function for input
//Q2.WAP to input two number and print the sum
let num1=parseInt(prompt("Enter first number:"));
let num2=parseInt(prompt("Enter second number:"));
let sum=num1+num2;
console.log("Value of sum is:",sum);
