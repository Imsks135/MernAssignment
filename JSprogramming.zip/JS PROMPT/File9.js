const prompt=require("prompt-sync")();//import prompt function for input
//Q9.WAP to print your name,class,city
let name=prompt("Enter name:");
let class_name=prompt("Enter class:");
let city=prompt("Enter city:");
console.log("My name:",name);
console.log("My class:",class_name);
console.log("My city:",city);