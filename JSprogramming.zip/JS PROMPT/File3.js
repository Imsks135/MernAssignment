const prompt=require("prompt-sync")();//import prompt function for input
//Q3.WAP to input two number and print their substraction
let num1=parseInt(prompt("Enter first number:"));
let num2=parseInt(prompt("Enter second number:"));
let sub=num1-num2;
console.log("subtraction:",sub);