const prompt=require("prompt-sync")();//import prompt function for input
//Q16.WAP to print area of circle
let length=parseInt(prompt("Enter length:"));
let breadth=parseInt(prompt("Enter breadth:"));
let area=length*breadth;
console.log("Area of rectangle:",area);