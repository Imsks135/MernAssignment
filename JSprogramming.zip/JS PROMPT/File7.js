const prompt=require("prompt-sync")();//import prompt function for input
//Q7.WAP to enter two number print their sum,diff,quotient
let num1=6;
let num2=2;
let sum=num1+num2;
let diff=num1-num2;
let quot=(num1/num2);
console.log("Sum is:",sum);
console.log("Difference:",diff);
console.log("Quotient:",quot);