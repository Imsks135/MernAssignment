const prompt=require("prompt-sync")();//import prompt function for input
//Q6.WAP to input a number print its square
let num=parseInt(prompt("Enter a number:"));
let squ=num*num;
console.log("Square:",squ);