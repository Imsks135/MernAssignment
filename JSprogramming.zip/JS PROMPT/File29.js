const prompt=require("prompt-sync")();//import prompt function for input
//LOOPING
//Q.1 WAP to print 1 to 10 number(using for,while,do while)
console.log("using for loop");
for(let i=1;i<=10;i++){
    console.log(i);
}
console.log("using while loop");
let j=1;
while(j<=10){
    console.log(j);
    j++;
}
console.log("using do while loop");
let k=1;
do{
    console.log(k);
    k++;
}
while(k<=10);