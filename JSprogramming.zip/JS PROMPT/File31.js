const prompt=require("prompt-sync")();//import prompt function for input
//LOOPING 
//Q.3 WAP tp print 10 number in reverse order of difference 2 (using for,while,do while)
console.log("using for loop");
for(let i=20;i>0;i-=2){
    console.log(i);
}
console.log("using while loop");
let j=20;
while(j>0){
    console.log(j);
    j-=2;
}
console.log("using do while loop");
let k=20;
do{
    console.log(k);
    k-=2;
}
while(k>0);